# FUTURE_CS_01 — Website Vulnerability Assessment

Report: `report/Website_Vulnerability_Assessment_Report.pdf`.

Evidence files and screenshots are in `evidence/`. This assessment uses the local OWASP Juice Shop training application. Review each of the 11 ZAP alerts before final submission; alert count alone does not establish confirmed vulnerabilities.
